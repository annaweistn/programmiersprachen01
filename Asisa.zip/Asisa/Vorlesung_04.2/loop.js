//i++ its the same than i = i + 1;
for (let i = 1; i <= 1; i++) {
console.log("counter variable", i);

for (let j = 1; j < 6; j++){
    console.log("counter variable j: ");
}


}
