let x = "6";
let y = "7";
function average(x, y) {
  return (x + y) / 2;
}
result = average (x,y);
console.log(result);

let stringX = "6";
let stringY = "7";




