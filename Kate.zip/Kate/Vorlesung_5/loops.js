// const arr = [1,2,3,4,5,6,7,8]
// function evenNum(arr){
    // for(let i=0; i<arr.length; i++){
       //  if (arr[i] % 2 === 0){
          //  console.log(arr[i])
        // }
    // }
// }
// evenNum(arr)

// Task 3
const arr = [1,2,3,5,6]
function getReverseNumbers(arr){
    for(let i = arr.lenght; i >=0; i-- ){
        console.log(arr[i])
    }
}
getReverseNumbers(arr)