console.log("this is 1st console")

setTimeout(() => console.log("this is 2nd console"), 5000)

setTimeout(() => console.log("this is 3nd console"), 3000)

console.log("this is 4th console")

// setInterval(() => console.log("this is interval"), 3000)